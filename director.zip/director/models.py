from django.db import models


# Create your models here.
class classroom_type(models.Model):
    Name = models.CharField(max_length=255,null=False)


class Classroom(models.Model):
    room_type = models.CharField(max_length=200)
    room_name = models.CharField(max_length=200)
    capacity = models.IntegerField()

class Department(models.Model):
    department_name = models.CharField(max_length=250,null=False) 


class Subject(models.Model):
    department_id = models.IntegerField()
    subject_name = models.CharField(max_length=200,null=False)
